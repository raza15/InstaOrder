class Session < ApplicationRecord
end
