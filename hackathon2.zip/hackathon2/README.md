
Run the project: Go to the main directory. On the terminal, run: rails server

Then go to localhost:3000

The files in which to add frontend: app/views/sessions/new.html.erb (this is the home page).

